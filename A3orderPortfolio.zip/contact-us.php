<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Веб разработчик Бондаренко Анатолий (создание сайтов), Харьков (Контакты)</title>
	<meta name="description" content="Веб разработка под ключ сайтов (создание сайтов) в Харькове: адаптивные и мобильные веб сайты, интернет-магазин, сайт компании, Landing Page, сайт-визитка, SEO"> 
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
 	<link type="images/x-icon" rel="shortcut icon" href="image/favicon1.ico" />
	<link href="css/main.css" rel="stylesheet">	
	<link href="css/Footer.css" rel="stylesheet">
	<link href="css/Header.css" rel="stylesheet">
	<link href="css/HomePage.css" rel="stylesheet">
	<link href="css/ContactUs.css" rel="stylesheet">
	
</head><!--/head-->

<body>
    <?php require_once "blocks/header-block.php"; ?>
    <section id="contact-info">
        <div class="center">                
            <h2>КАК СВЯЗАТЬСЯ?</h2>
            <p class="lead"></p>
        </div>
        <div class="gmap-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center">
                        <div class="gmap">
							<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d82097.59061718249!2d36.22724533081052!3d49.98230259510286!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2sua!4v1488489432148" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 map-content">
                        <ul class="row">
                            <li class="">
                                <address>
                           <span class="fa-stack fa-lg"> 
                            <i class="fa fa-circle fa-stack-2x icon-color"></i>
                            <i class="fa fa-phone fa-stack-1x fa-inverse"></i>
                            </span>&nbsp;+3(095)867-44-78;
                            <br/>
                            <span class="fa-stack fa-lg"> 
                            <i class="fa fa-circle fa-stack-2x icon-color"></i>
                            <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                            </span>&nbsp;anatoliybon@mail.ua;
                            <br/>
                            <span class="fa-stack fa-lg"> 
                            <i class="fa fa-circle fa-stack-2x icon-color"></i>
                            <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                            </span>&nbsp;anatoliybon@rambler.ru;
                            <br/>
							<span class="fa-stack fa-lg"> 
                            <i class="fa fa-circle fa-stack-2x icon-color"></i>
                            <i class="fa fa-skype fa-stack-1x fa-inverse"></i>
                            </span>&nbsp;bondarenko_anatoliy13;
                            <br/>							
                            <span class="fa-stack fa-lg"> 
                            <i class="fa fa-circle fa-stack-2x icon-color"></i>
                            <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                            </span>&nbsp;Украина, Харьков.
                            <br/>
                            <div class="btn-toolbar" style="margin-top: 20px">

                            </div>
                                </address>                         
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>  <!--/gmap_area -->

    <section id="contact-page">
        <div class="container wow fadeInDown">
            <div class="center">        
                <h2>ОСТАВИТЬ СООБЩЕНИЕ</h2>
                <p class="lead"></p>
            </div> 
            <div class="row contact-wrap"> 
                    <?php require_once "blocks/form-block.php"; ?>
            </div><!--/.row-->
        </div><!--/.container-->
    </section><!--/#contact-page-->
   <?php require_once "blocks/footer-block.php"; ?>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
	<script src="/feedback/js/jquery-1.12.4.min.js"></script>
	<script src="/feedback/js/bootstrap.min.js"></script>
	<script src="/feedback/script.js"></script>

</body>
</html>