
    <section id="bottom">
        <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="row">
            <h3>ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ</h3>			
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="widget">
                        <ul>
                            <li><a href="index.php">Главная</a></li>
                            <li><a href="about-us.php">О себе</a></li>
                        </ul>
                    </div>    
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="widget">
                        <ul>
                            <li><a href="skills.php">Навыки</a></li>
                            <li><a href="portfolio.php">Портфолио</a></li>
                        </ul>
                    </div>    
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="widget">
                        <ul>
                            <li><a href="services.php">Услуги</a></li>
                            <li><a href="contact-us.php">Контакты</a></li>
                        </ul>
                    </div>    
                </div>
            </div>
        </div>
    </section><!--/#bottom-->

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    Бондаренко Анатолий &#169; 2017. Все права защищены.
                </div>
                <div class="col-sm-6">
                </div>
            </div>
        </div>
    </footer><!--/#footer-->