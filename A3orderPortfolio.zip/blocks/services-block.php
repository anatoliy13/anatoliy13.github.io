
    <section id="services" class="service-item">
	   <div class="container">
            <div class="center wow fadeInDown">
                <h2>УСЛУГИ</h2>
                <p class="lead">Любые сайты "под ключ", как с нуля, так и с использованием CMS</p>
            </div>

            <div class="row">

                <div class="col-sm-6 col-md-6 col-lg-4">
                    <div class="media services-wrap wow fadeInDown">
                        <div class="pull-left">
                            <img class="img-responsive" src="image/services/services3.png">
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Создание сайтов "под ключ", SEO</h3>
                            <p>Цена зависит от сроков и сложности проекта</p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-6 col-lg-4">
                    <div class="media services-wrap wow fadeInDown">
                        <div class="pull-left">
                            <img class="img-responsive" src="image/services/services5.png">
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Адаптивные и мобильные сайты</h3>
                            <p>Цена зависит от сроков и сложности проекта</p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-6 col-lg-4">
                    <div class="media services-wrap wow fadeInDown">
                        <div class="pull-left">
                            <img class="img-responsive" src="image/services/services1.png">
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Разработка Landing Page</h3>
                            <p>Цена зависит от сроков и сложности проекта</p>
                        </div>
                    </div>
                </div>  

                <div class="col-sm-6 col-md-6 col-lg-4">
                    <div class="media services-wrap wow fadeInDown">
                        <div class="pull-left">
                            <img class="img-responsive" src="image/services/services4.png">
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Создание сайта компании</h3>
                            <p>Цена зависит от сроков и сложности проекта</p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-6 col-lg-4">
                    <div class="media services-wrap wow fadeInDown">
                        <div class="pull-left">
                            <img class="img-responsive" src="image/services/services2.png">
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Создание сайта-визитки</h3>
                            <p>Цена зависит от сроков и сложности проекта</p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-6 col-lg-4">
                    <div class="media services-wrap wow fadeInDown">
                        <div class="pull-left">
                            <img class="img-responsive" src="image/services/services6.png">
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Разработка интернет-магазинов</h3>
                            <p>Цена зависит от сроков и сложности проекта</p>
                        </div>
                    </div>
                </div>                                                
            </div><!--/.row-->
        </div><!--/.container-->
    </section><!--/#services-->

	
