
    <section id="recent-works">
        <div class="container">
            <div class="center wow fadeInDown">
                <h2>ПОРТФОЛИО</h2>
                <p class="lead">Любые сайты "под ключ", как с нуля, так и с использованием CMS</p>
            </div>

            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item1.png" alt="Портфолио1">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://car-showroom.esy.es/" target="_blank">Landing Page для автосалона ЛЮБОТИН-Ц</a> </h3>
                                <a class="preview" href="image/portfolio/full/item1.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item2.png" alt="Портфолио2">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://lesana-volos.ru/" target="_blank">Сайт для компании ЛЕСАНА-ВОЛОС</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item2.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div> 

                <div style="display: none" class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item3.png" alt="Портфолио3">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://lesana-volos.ru/price.php" target="_blank">Сайт для компании ЛЕСАНА-ВОЛОС </a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item3.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item4.png" alt="Портфолио4">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://student-life.esy.es/" target="_blank">Landing Page  для компании StudentLife </a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item4.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   
                
                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item5.png" alt="Портфолио5">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://student-life-uk.esy.es/" target="_blank">Landing Page №1 для Бондаренко Анатолия</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item5.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item6.png" alt="Портфолио6">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://bondarenko13.esy.es/" target="_blank">Landing Page №2 для Бондаренко Анатолия</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item6.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item7.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://sad1.esy.es/" target="_blank">Сайт-каталог цветов</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item7.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item8.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://sad1.esy.es/decorative.php" target="_blank">Сайт-каталог цветов</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item8.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   
				<div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item9.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://student-life-uk-kh.esy.es/" target="_blank">Магазин по продаже телефонов</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item9.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div> 
				<div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item10.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://my-site-wp.esy.es/" target="_blank">Landing Page №3 для Бондаренко Анатолия</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item10.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div> 
				<div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item11.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://blog-blog.esy.es/" target="_blank">Блог по питанию для малышей</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item11.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>    	
				<div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item12.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://woocommerce13.esy.es/" target="_blank">Магазин по продаже детских автомобилей</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item12.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>  
				<div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item13.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://a7joomla.esy.es/" target="_blank">Блог по советам садоводам</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item13.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>  				
            </div><!--/.row-->
        </div><!--/.container-->
    </section><!--/#recent-works-->
