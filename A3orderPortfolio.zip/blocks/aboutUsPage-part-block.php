
    <section id="partner" class="distance section_parm">
        <div class="container">
            <div class="center wow fadeInDown">
                <h2>О СЕБЕ</h2>
            </div>    
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 about-me-parm wow fadeInDown">
                            <ul class="fa-ul">
                                <li><span class="main-point">&nbsp;Образование:</span>
                                    <ul class="fa-ul about-me">
										<li><i class="fa-li fa fa-check-square icon-color"></i>2016 - Доктор технических наук.</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2015-2016 - Компьютерная академия "Шаг", курсы "Современные Web технологии и интернет-маркетинг".</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>С 2015 - Курсы английского языка.</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2015 - Компьютерная академия "Шаг", курсы "Тестирование программного обеспечения".</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2013-2016 - Докторантура Национального технического университета "Харьковский политехнический институт" (НTУ "ХПИ").</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2013 - Доцент кафедры автомобиле- и тракторостроения НTУ "ХПИ".</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2010 - Кандидат технических наук.</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2006-2009 - Аспирантура НTУ "ХПИ".</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2004-2006 - Степень специалиста, менеджер-экономист (НTУ "ХПИ", заочная форма обучения).</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2000-2006 - Степень магистра, инженер-механик исследователь, диплом с отличием (НTУ "ХПИ").</li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 about-me-parm wow fadeInDown">
                            <ul class="fa-ul">
                                <li><span class="main-point">&nbsp;Опыт работы:</span>
                                    <ul class="fa-ul about-me">
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>С 2016 - Веб разработчик
										</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>C 2011 - Доцент кафедры автомобиле- и тракторостроения.</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2013-2014 - Глава совета молодых ученых НТУ "ХПИ". Содействие развитию межвузовского сотрудничества. Организация контактов с различными учреждениями, организациями и предприятиями. Проверка соблюдения прав молодых ученых. Курирование работы более 500 молодых ученых НТУ "ХПИ".
                                        </li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>C 2010 - Заместитель декана факультета транспортного машиностроения. Управление научно-технической работой на факультете. Продвижение инноваций и изобретений. Курирование работы более 50 научных работников и более 20 аспирантов факультета.
                                        </li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>2006-2011 - Преподаватель кафедры автомобиле- и тракторостроения.</li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 about-me-parm wow fadeInDown">
                            <ul class="fa-ul">
                                <li><span class="main-point">&nbsp;Дополнительно:</span>
                                    <ul class="fa-ul about-me">
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>Личные качества: коммуникабельность, высокая работоспособность, настойчивость, целеустремленность, ответственное отношение к своим обязанностям, дружелюбие и готовность помочь, постоянное совершенствование своих знаний, желание обеспечить высокую производительность и качество работы, творческий подход к решению проблем.</li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>Награды: дважды стипендиат Кабинета Министров Украины (2014-2015, 2016).
                                        </li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>Научные труды: более 100 статей и тезисов, 5 патентов и т.д.
                                        </li>
                                        <li><i class="fa-li fa fa-check-square icon-color"></i>Английский: Upper-intermediate.</li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>      
        </div><!--/.container-->
    </section><!--/#partner-->
