
	    <section id="conatcat-info">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-8">
                    <div class="media contact-info wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="pull-left">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="media-body">
                            <h2>Есть вопросы, хотите заказать сайт?</h2>
                            <p>Звоните +38095 867 44 78</p>
                        </div>
                    </div>
                </div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
					<img src="image/design1.png" style="width: 100%;">
                </div>
            </div>
        </div><!--/.container-->    
    </section><!--/#conatcat-info-->
	