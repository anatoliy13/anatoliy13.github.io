<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Веб разработчик Бондаренко Анатолий (создание сайтов), Харьков (Навыки)</title>
	<meta name="description" content="Веб разработка под ключ сайтов (создание сайтов) в Харькове: адаптивные и мобильные веб сайты, интернет-магазин, сайт компании, Landing Page, сайт-визитка, SEO"> 
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
 	<link type="images/x-icon" rel="shortcut icon" href="image/favicon1.ico" />
	<link href="css/Footer.css" rel="stylesheet">
	<link href="css/Header.css" rel="stylesheet">
	<link href="css/AboutUsPage.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/HomePage.css" rel="stylesheet">

</head>

<body>
 <?php require_once "blocks/header-block.php"; ?>
           <div class="container">
			<!-- Our Skill -->
			<div class="skill-wrap clearfix">
				<div class="center wow fadeInDown">
					<h2>НАВЫКИ</h2>
					<p class="lead">Любые сайты "под ключ", как с нуля, так и с использованием CMS</p>
				</div>
				<div class="row">
		
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="HTML-skill">
								<p><em>95%</em></p>
								<p>HTML 5</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="CSS-skill">
								<p><em>95%</em></p>
								<p>CSS 3</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Bootstrap-skill">
								<p><em>95%</em></p>
								<p>Bootstrap 3</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="LESS-skill">
								<p><em>85%</em></p>
								<p>LESS</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Responsive-skill">
								<p><em>95%</em></p>
								<p>Responsive design</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="JavaScript-skill">
								<p><em>70%</em></p>
								<p>JavaScript</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="jQuery-skill">
								<p><em>85%</em></p>
								<p>jQuery</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Php-skill">
								<p><em>85%</em></p>
								<p>Php 5</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="MySQL-skill">
								<p><em>75%</em></p>
								<p>MySQL</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="WordPress-skill">
								<p><em>90%</em></p>
								<p>WordPress</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Joomla-skill">
								<p><em>85%</em></p>
								<p>Joomla</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="OpenCart-skill">
								<p><em>85%</em></p>
								<p>OpenCart</p>
							</div>
						</div>
					</div>
					<div style="display: none;"  class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Bitriks-skill">
								<p><em>70%</em></p>
								<p>1C-Битрикс</p>
							</div>
						</div>
					</div>
					<div style="display: none;"  class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="ModX-skill">
								<p><em>70%</em></p>
								<p>ModX</p>
							</div>
						</div>
					</div>
					<div style="display: none;"  class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Drupal-skill">
								<p><em>70%</em></p>
								<p>Drupal</p>
							</div>
						</div>
					</div>
					<div style="display: none;"  class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Magento-skill">
								<p><em>70%</em></p>
								<p>Magento</p>
							</div>
						</div>
					</div>
					<div style="display: none;" class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Yii-skill">
								<p><em>70%</em></p>
								<p>Yii PHP Framework</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="SEO-skill">
								<p><em>95%</em></p>
								<p>SEO</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
						<div class="sinlge-skill wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="Photoshop-skill">
								<p><em>90%</em></p>
								<p>Photoshop</p>
							</div>
						</div>
					</div>
				</div>
	
            </div><!--/.our-skill-->
			
        </div>
<?php require_once "blocks/footer-block.php"; ?>

    <script src="js/jquery.js"></script>
    <script type="text/javascript">
        $('.carousel').carousel()
    </script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>