<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Веб разработчик Бондаренко Анатолий (создание сайтов), Харьков (Портфолио)</title>
	<meta name="description" content="Веб разработка под ключ сайтов (создание сайтов) в Харькове: адаптивные и мобильные веб сайты, интернет-магазин, сайт компании, Landing Page, сайт-визитка, SEO"> 
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
	<link href="css/Footer.css" rel="stylesheet">
	<link href="css/Header.css" rel="stylesheet">
	<link href="css/HomePage.css" rel="stylesheet">
	<link href="css/Portfolio.css" rel="stylesheet">
			 
<body class="homepage">
    <?php require_once "blocks/header-block.php"; ?>
    <section id="portfolio">
        <div class="container">
            <div class="center">
               <h2>ПОРТФОЛИО</h2>
               <p class="lead">Любые сайты "под ключ", как с нуля, так и с использованием CMS</p>
            </div>
            <ul class="portfolio-filter text-center">
                <li><a class="btn btn-default active" href="#" data-filter="*">Все работы</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".html-css">HTML 5, CSS 3</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".bootstrap">Bootstrap 3</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".less">LESS</a></li>
				<li><a class="btn btn-default" href="#" data-filter=".responsived">Responsive design</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".js-jq">JavaScript, jQuery</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".php-mysql">Php 5, MySQL</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".wordpress">WordPress</a></li>
				<li><a class="btn btn-default" href="#" data-filter=".wordpress0">Темы для WordPress</a></li>
				<li><a class="btn btn-default" href="#" data-filter=".joomla">Joomla</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".opencart">OpenCart</a></li>
                <li style="display: none"><a class="btn btn-default" href="#" data-filter=".bitriks">1C-Битрикс</a></li>
                <li style="display: none"><a class="btn btn-default" href="#" data-filter=".modx">ModX</a></li>
				<li style="display: none"><a class="btn btn-default" href="#" data-filter=".drupal">Drupal</a></li>
				<li style="display: none"><a class="btn btn-default" href="#" data-filter=".magento">Magento</a></li>
                <li style="display: none"><a class="btn btn-default" href="#" data-filter=".yii">Yii PHP Framework</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".seo">SEO</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".photoshop">Photoshop</a></li>
				<li><a class="btn btn-default" href="#" data-filter=".all-all">Сайт "под ключ"</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".cms">CMS</a></li>
				<li><a class="btn btn-default" href="#" data-filter=".adaptive">Адаптивные и мобильные сайты</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".landing">Landing Page</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".site-company">Cайт компании</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".site-visit">Cайт-визитка</a></li>
				<li><a class="btn btn-default" href="#" data-filter=".internet-shop">Интернет-магазин</a></li>
            </ul><!--/#portfolio-filter-->
            <div class="row">
				<div class="portfolio-items">
			
			
			    <div class="portfolio-item html-css bootstrap responsived  js-jq php-mysql photoshop all-all adaptive landing col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item1.png" alt="Портфолио1">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://car-showroom.esy.es/" target="_blank">Landing Page для автосалона ЛЮБОТИН-Ц</a> </h3>
                                <a class="preview" href="image/portfolio/full/item1.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="portfolio-item html-css bootstrap responsived js-jq  php-mysql photoshop all-all adaptive site-company site-visit col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item2.png" alt="Портфолио2">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://lesana-volos.ru/" target="_blank">Сайт для компании ЛЕСАНА-ВОЛОС</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item2.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div> 

                 <!--  <div class="portfolio-item html-css bootstrap responsived js-jq php-mysql photoshop all-all adaptive site-company site-visit col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item3.png" alt="Портфолио3">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://lesana-volos.ru/price.php" target="_blank">Сайт для компании ЛЕСАНА-ВОЛОС </a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item3.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>  --> 

                <div class="portfolio-item html-css bootstrap responsived js-jq photoshop all-all adaptive landing col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item4.png" alt="Портфолио4">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://student-life.esy.es/" target="_blank">Landing Page  для компании StudentLife </a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item4.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   
                
                <div class="portfolio-item html-css  bootstrap less responsived js-jq php-mysql photoshop adaptive all-all site-company landing site-visit col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item5.png" alt="Портфолио5">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://student-life-uk.esy.es/" target="_blank">Landing Page №1 для Бондаренко Анатолия</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item5.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="portfolio-item html-css bootstrap less responsived  js-jq php-mysql seo photoshop adaptive all-all landing col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item6.png" alt="Портфолио6">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://bondarenko13.esy.es/" target="_blank">Landing Page №2 для Бондаренко Анатолия</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item6.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="portfolio-item html-css bootstrap responsived js-jq php-mysql seo photoshop adaptive all-all site-company site-visit col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item7.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://sad1.esy.es/" target="_blank">Сайт-каталог цветов</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item7.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="portfolio-item html-css bootstrap responsived js-jq php-mysql seo photoshop adaptive all-all site-company site-visit col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item8.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://sad1.esy.es/decorative.php" target="_blank">Сайт-каталог цветов</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item8.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   
			    <div class="portfolio-item html-css js-jq php-mysql photoshop all-all internet-shop col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item9.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://student-life-uk-kh.esy.es/" target="_blank">Магазин по продаже телефонов</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item9.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div> 
			    <div class="portfolio-item html-css  bootstrap less responsived cms adaptive landing js-jq php-mysql photoshop all-all  wordpress wordpress0 col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item10.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://my-site-wp.esy.es/" target="_blank">Landing Page №3 для Бондаренко Анатолия</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item10.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>   
			    <div class="portfolio-item html-css responsived cms adaptive  php-mysql photoshop all-all  wordpress col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item11.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://blog-blog.esy.es/" target="_blank">Блог по питанию для малышей</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item11.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>  
			    <div class="portfolio-item html-css responsived cms adaptive  php-mysql photoshop all-all internet-shop wordpress col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item12.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://woocommerce13.esy.es/" target="_blank">Магазин по продаже детских автомобилей</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item12.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>
			    <div class="portfolio-item html-css responsived cms adaptive  php-mysql photoshop all-all joomla col-xs-12 col-sm-4 col-md-3">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="image/portfolio/recent/item13.png" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="http://a7joomla.esy.es/" target="_blank">Блог по советам садоводам</a></h3>
                                <p></p>
                                <a class="preview" href="image/portfolio/full/item13.png" rel="prettyPhoto"><i class="fa fa-eye"></i> Просмотр скриншота</a>
                            </div> 
                        </div>
                    </div>
                </div>    				
				</div>
            </div>
        </div>
    </section><!--/#portfolio-item-->
    <?php require_once "blocks/footer-block.php"; ?>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>