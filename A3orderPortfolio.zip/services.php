<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Веб разработчик Бондаренко Анатолий (создание сайтов), Харьков (Услуги)</title>
	<meta name="description" content="Веб разработка под ключ сайтов (создание сайтов) в Харькове: адаптивные и мобильные веб сайты, интернет-магазин, сайт компании, Landing Page, сайт-визитка, SEO"> 
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
 	<link type="images/x-icon" rel="shortcut icon" href="image/favicon1.ico" />
	<link href="css/main.css" rel="stylesheet">	
	<link href="css/Footer.css" rel="stylesheet">
	<link href="css/Header.css" rel="stylesheet">
	<link href="css/HomePage.css" rel="stylesheet">
</head>
<body class="homepage">
    <?php require_once "blocks/header-block.php"; ?>
	<?php require_once "blocks/services-block.php"; ?>
    <?php require_once "blocks/footer-block.php"; ?>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script> <!--Съезжающие экраны-->
</body>
</html>